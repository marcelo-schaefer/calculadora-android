package com.example.aap_marcelo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {

    private var sequenciaOperacao : String  = "";
    private var valorTotal : Int  = 0;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

     fun clickAcao(view: View) {
        var valor : String = findViewById<Button>(view.id).toString();
         sequenciaOperacao += valor;
    }

    fun limpar() {
        sequenciaOperacao = "";
    }

    fun resultado(){

    }

}